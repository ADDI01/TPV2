Es una plantilla de proyecto Visual Studio 2019 (para usar con las prácticas) con todas las librerías SDL
 que necesitamos. Además, incluye un conjunto de clases que nos permiten trabajar con SDL de manera más fácil 
 (compila con x64).